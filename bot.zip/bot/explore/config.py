s_r_tolerance = 20  # 100%
period = 20 # candles
