symbol = 'UNI/USDT'
timeframe = '30m'
amount_usdt = 8  # Amount in USDT to spend
leverage = 20
per = 14
trailingStopLoss = .35 # .25 is 25% of current change
